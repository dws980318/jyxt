<template>
  <div>
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: "Index",
  data() {
    return {
      radio: "2"
    };
  }
};
</script>

<style>

</style>
